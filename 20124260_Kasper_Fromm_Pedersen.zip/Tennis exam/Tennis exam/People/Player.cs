﻿namespace TennisExam.People
{
    internal class Player : Person
    {

    }
}
