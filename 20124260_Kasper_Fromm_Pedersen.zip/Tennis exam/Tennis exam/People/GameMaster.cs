﻿namespace TennisExam.People
{
    internal class GameMaster : Referee
    {

    }
}
