﻿using System;

namespace TennisExam.Data
{
    static class StaticRandom
    {
        public static Random Rand = new Random();
    }
}
