﻿using TennisExam.Data;

namespace TennisExam.TournamentLogic
{
    internal class Set
    {
        public int Score1 { get; set; }
        public int Score2 { get; set; }

        public void PlaySet()
        {
            var rand = StaticRandom.Rand;
            if (rand.Next(0, 100) < 49)
            {
                Score1 = 6;
                Score2 = rand.Next(0, 6);
            }
            else
            {
                Score2 = 6;
                Score1 = rand.Next(0, 6);
            }
        }
    }
}
